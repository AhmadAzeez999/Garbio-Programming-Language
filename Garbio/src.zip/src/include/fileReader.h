#ifndef FILEREADER_H
#define FILEREADER_H

char* get_file_contents(const char* filepath);

#endif